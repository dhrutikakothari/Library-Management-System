package com.jsp.lms.view;

import com.jsp.lms.model.Book;
import java.util.Scanner;

import javax.sql.rowset.serial.SQLOutputImpl;

import com.jsp.lms.controller.Controller;
import com.jsp.lms.model.Book;
import com.jsp.lms.model.Library;

public class View {
	// to access and manipulate the library information without creating multiple
	// instances
	// of the Library class.

	// The View class contains a static instance of the Library class and a Scanner
	// object for user input.
	public static Library library = new Library();// static single line initilizer

	static Scanner myInput = new Scanner(System.in);
	static Controller controller = new Controller();

	public static Library getLibrary() {
		return library;
	}

	public static void setLibrary(Library library) {
		View.library = library;
	}

	static {// static multi-line initilizer
		System.out.println("-------Welcome to Lirary Management System");

		System.out.print("Enter name of libray: ");
		String libraryName = myInput.nextLine();
		library.setLibraryName(libraryName);

		System.out.print("Enter address of library:");
		library.setLibraryAddress(myInput.nextLine());

		System.out.print("Enter Pincode: ");
		library.setPincode(myInput.nextInt());
		myInput.nextLine();// Consumes the Newline Character:
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		do {
			System.out.println("Select option to perform");
			System.out.println("1.Add book\n2.Remove book\n3.Update book\n4.Get book\n0.Exit");
			System.out.print("Enter digit respective to desired option:  ");
			byte userChoice = myInput.nextByte();
			myInput.nextLine();

			switch (userChoice) {
			case 0:
				myInput.close();
				System.out.println("---------E X I T E D---------");
				System.exit(0);
				break;
			case 1:

				Book book = new Book();// Create a new Book object
				controller.addBook(book);// Add the newly created book to the library using the controller

				System.out.print("enter book name: ");
				book.setBookName(myInput.nextLine());// Read the user input for the book name and set it in the book
														// object

				System.out.print("enter author name: ");
				book.setBookAuthor(myInput.nextLine());

				System.out.println("Enter the price of book");
				book.setBookPrice(myInput.nextDouble());

				System.out.println("Book added successfully.");
				break;

			case 2:
				System.out.print("Enter book name to be remove:   ");
				String bookToRemove = myInput.nextLine();
				if (controller.removeBook(bookToRemove)) {
					System.out.println("Requested book has been removed.");
				} else {
					System.out.println("Book does not exit cannot be remove.");
				}
				break;

			case 3:
				System.out.print("Enter book name to update: ");
//				String bookUpdate = myInput.nextLine();
				Book bookExist = controller.getBook(myInput.nextLine());
				if (bookExist != null) {// book exit
					Book bookToUpdate = bookExist;
					System.out.println("What to update");
					System.out.println("1.Book name\n2.Author name\n3.Book price");
					System.out.print("Enter digit respective to desired option:  ");

					byte updateChoice = myInput.nextByte();
					myInput.nextLine();
					switch (updateChoice) {
					case 1:
						System.out.print("Enter a book name to update: ");
//						String newBookName = myInput.nextLine();
						bookToUpdate.setBookName(myInput.nextLine());
						break;
					case 2:
						System.out.print("Enter a author name to update: ");
						// String newAuthorName = myInput.nextLine();
						bookToUpdate.setBookAuthor(myInput.nextLine());
						break;

					case 3:
						System.out.print("Enter a book price to update: ");
						//double newBookPrice = myInput.nextDouble();
						
						bookToUpdate.setBookPrice(myInput.nextDouble());
						myInput.nextLine();
						

						break;

					default:
						System.out.println("please enter valid option.");
						break;
					}
					if (controller.update(bookExist, bookToUpdate)) {
			            System.out.println("Book updated successfully.");
			        } else {
			            System.out.println("Failed to update the book. Please try again.");
			        }
					
				}

//				System.out.print("Enter the book name to update: ");
//				String bookToUpdate = myInput.nextLine();
//
//				// Check if the book exists before updating
//				if (controller.getBook(bookToUpdate) != null) {
//					Book newBook = new Book();
//					System.out.print("Enter new book name: ");
//					newBook.setBookName(myInput.nextLine());
//
//					System.out.print("Enter new author name: ");
//					newBook.setBookAuthor(myInput.nextLine());
//
//					System.out.println("Enter the new price of the book");
//					newBook.setBookPrice(myInput.nextDouble());
//
//					controller.updateBook(bookToUpdate, newBook);
//				} else {
//					System.out.println("Book not found. Update failed.");
//				}
				break;

			case 4:

				System.out.println("Enter book name you are looking for : ");
				Book fetchBook = controller.getBook(myInput.nextLine());// Read the user input for the book name and
																		// call the controller's getBook method
				if (fetchBook != null) {// book is exist
					System.out.println("Book is available");
					System.out.println("Details:");
					System.out.println(fetchBook);// toString

				} else {// not exit
					System.out.println("book is not available ");
				}

				break;

			default:
				System.out.println("Invalid option.");
				break;
			}

		} while (true);

	}

}
