package com.jsp.lms.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.jsp.lms.model.Book;
import com.jsp.lms.model.Library;
import com.jsp.lms.view.View;

public class Controller {

	private Library library = View.getLibrary();

	public void addBook(Book book) {
		List<Book> books = library.getBooks();// Retrieves the current list of books from the library using the getBooks
												// method.
		if (books == null)// Checks if the retrieved list of books is null.
		{
			books = new ArrayList<>();// initializes a new ArrayList to store books.
		}
		books.add(book);
		library.setBooks(books);// updated list of books back to the library using the setBooks method.
	}

	public Book getBook(String bookName) {
		List<Book> books = library.getBooks();
		if (books != null) {// list of books is not null.
			for (Book book : books) {// Iterates through the list of books using a for-each loop.
				if (book.getBookName().equalsIgnoreCase(bookName))// name of the current book in the loop matches the
																	// specified
				{
					return book;

				}
			}
		}
		return null;
	}

	public boolean update(Book bookExist, Book bookUpdate) {
		List<Book> books = library.getBooks();
		for (Book book : books) {
			if (book.getBookName().equalsIgnoreCase(bookExist.getBookName())) {
				books.remove(bookExist);
				books.add(bookUpdate);
				return true;
			}

		}
		return false;
	}

	public boolean removeBook(String bookName) {
		Book book = getBook(bookName);
		if (book != null) {// Book exist
			List<Book> books = library.getBooks();
			boolean remove = books.remove(book);
			library.setBooks(books);
			return true;
		}
		return false;
	}

//
//    public void updateBook(String bookName, Book newBook) {
//        List<Book> books = library.getBooks();
//        if (books != null) {
//            for (int i = 0; i < books.size(); i++) {
//                Book book = books.get(i);
//                if (book.getBookName().equalsIgnoreCase(bookName)) {
//                    books.set(i, newBook);
//                    System.out.println("Book updated successfully!");
//                    return;
//                }
//            }
//        }
//        System.out.println("Book not found. Update failed.");
//    }
}
