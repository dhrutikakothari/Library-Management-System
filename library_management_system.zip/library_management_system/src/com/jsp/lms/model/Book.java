package com.jsp.lms.model;

//SE--1.8VERSION
//Lambda Expressions:  functional programming style in Java.
//Functional Programming Features:
//Streams API:  It enables operations like filter, map, and reduce on collections, making it easier to 
//               express complex data manipulations.
//Date and Time API:
//Default Methods in Interfaces:
//Functional Interfaces:




public class Book {
	//The Book class represents a book and has private attributes bookName, bookAuthor, and bookPrice.
	private String bookName;//private keyword in Java is an access modifier 
	private String bookAuthor;
	private double bookPrice;
	public String getBookName() {
		return bookName;
	}
	//external classes cannot directly access or modify the data. Access
	//to the data is controlled through getter and setter methods.
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookAuthor() {
		return bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	public String toString(){
	       return "Book [bookName=" + bookName + ", bookAuthor=" + bookAuthor + ", bookPrice=" + bookPrice + "]";
	}

}

